#MODUL LUAS 

def segitiga(a, t):
    return 1/2 * a * t

def persegi (p, l):
    return p * l

def lingkaran(r):
    return 3.14 * (r**2)