#MODULE FUNGSI PERHITUNGAN 

#PENJUMLAHAN :
def penjumlahan(a, b):  
    print("Hasil Penjumlahan dari:", a, '+', b, '=', a + b)

#PENGURANGAN :
def Pengurangan(a, b):
    print("Hasil Pengurangan dari:", a, '-', b, '=', a - b)

#PERKALIAN :
def Perkalian(a, b):
    print("Hasil Pengurangan dari:", a, '*', b, '=', a * b)

#PEMBAGIAN :
def Pembagian(a, b):
    print("Hasil Pembagian dari:", a, '/', b, '=', a / b)